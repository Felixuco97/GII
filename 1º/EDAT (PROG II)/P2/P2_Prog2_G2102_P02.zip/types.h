#ifndef _TYPES_H
#define _TYPES_H

#include <stdlib.h>
#include <stdio.h>

typedef enum{
    ERROR,
    OK,
    END
}Status;

typedef enum{
    FALSE,
    TRUE
}Bool;

#endif