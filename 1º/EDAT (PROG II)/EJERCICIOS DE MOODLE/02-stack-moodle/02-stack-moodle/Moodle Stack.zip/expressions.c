
#include "expressions.h"
#include "stack.h"
#include "types.h"
#include <ctype.h> // for isdigit()
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#define OPERATORS "+-*/%"

// is char c an operator?
Bool isOperator(char c) {
  char *oper = OPERATORS;
  char *pc;

  // exclude the char '\0' as operator
  if (c == '\0')
    return FALSE;

  // search for c in operators
  pc = strchr(oper, c);

  if (!pc)
    return FALSE;
  return TRUE;
}

// is char c an operand?
// accepts anything that is not an operator
Bool isOperand(char c) {
  Bool b;
  b = (isOperator(c) == TRUE) ? FALSE : TRUE;
  return b;
}

// is char c a digit
Bool isIntOperand(char c) { return isdigit(c) ? TRUE : FALSE; }

// evaluate expresion with operator oper
int evaluate(int arg1, int arg2, char oper) {
  int p = 0;
  
  switch (oper) {
  case '+':
    p = arg1 + arg2;
    break;
  case '-':
    p = arg1 - arg2;
    break;
  case '*':
    p = arg1 * arg2;
    break;
  case '/':
    p = arg1 / arg2;
    break;
  default:
    printf("Invalid operator");
  }
  return p;
}
/******************************************/

// START YOUR CODE

// return TRUE if string str has well-balanced parenthesis

Bool balancedParens(char *str) { 

  Status st = OK;
  Stack *s = NULL;
  int i = 0;

  s = stack_init();

  if(s == NULL)
    st = ERROR;

  while(str[i]!='\0' && st == OK){
    if(str[i] == '('){
      stack_push(s,&str[i]);
    }
    else if(str[i] == ')'){
      if(stack_isEmpty(s) == FALSE){
        if(stack_pop(s) == NULL){
          st = ERROR;
        }
      }
      else{
        st = ERROR;
      }
    }
    i++;
  }

  if(st == OK && stack_isEmpty(s) == FALSE){
    st = ERROR;
  }

  stack_free(s);

  if(st == OK){
    return TRUE;
  }else{
    return FALSE;
  }
}

// evaluate the postfix expression in expr
// return OK or ERROR
// if no error, *result contains the result of evaluating the expression

Status evalPostfix(char *expr, int *result) { 
  
  Status st = OK;
  Stack *s = NULL;
  int i = 0;
  int *arg1;
  int *arg2;
  int *res = NULL;
  int eval = 0;

  s = stack_init();

  if(s == NULL)
    st = ERROR;;

  while(expr[i]!='\0' && st == OK){
    if(isIntOperand(expr[i]) == TRUE){
        stack_push(s,int_init(expr[i]-'0'));
    }
    else if(isOperator(expr[i]) == TRUE){
        if(stack_isEmpty(s) == FALSE){
          arg2 = stack_pop(s);
        }
        else{
          st = ERROR;
        }
        if(stack_isEmpty(s) == FALSE){
          arg1 = stack_pop(s);
        }
        else{
          st = ERROR;
        }
          eval = evaluate(*arg1,*arg2,expr[i]);
          stack_push(s,int_init(eval));
    }
    i++;
  }
  if(st == OK){
    res = stack_pop(s);
    *result = *res;
  }

  if(stack_isEmpty(s) == FALSE){
    st = ERROR;
  }
  
  stack_free(s);
  return st; 
}
// END CODE